import org.bson.conversions.Bson;

import static com.mongodb.client.model.Filters.*;

public enum ComparisonSign {
    EQUALTO{
        public Bson apply(String s,double d){
            return eq(s,d);
        }
    },
    GREATERTHAN{
        public Bson apply(String s,double d){
            return gt(s,d);
        }
    },
    LESSTHAN{
        public Bson apply(String s, double d){
            return lt(s,d);
        }
    },
    GREATERTHANOREQUALTO{
        public Bson apply(String s,double d){
            return or(ComparisonSign.GREATERTHAN.apply(s,d),ComparisonSign.EQUALTO.apply(s,d));
        }
    },
    LESSTHANOREQUALTO{
        public Bson apply(String s,double d){
            return or(ComparisonSign.LESSTHAN.apply(s,d),ComparisonSign.EQUALTO.apply(s,d));
        }
    };



    public abstract Bson apply(String s, double d);


}
