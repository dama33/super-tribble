import javafx.util.Pair;

import java.util.List;
import java.util.UUID;

public class Settings{
    private List<Pair<String, String>> settings;

    public Settings(List<Pair<String, String>> l){
        settings=l;
    }

    public Pair<String,String> getPair(int index){
        return settings.get(index);
    }

    public List<Pair<String,String>> getListOfPairs() {
        return settings;
    }

}
