import javafx.util.Pair;
import java.util.List;
import java.util.UUID;

public class RunConfiguration extends Settings{
    private UUID commit;
    private String name;

    public RunConfiguration(List<Pair<String,String>> l,String name) {
        super(l);
        this.name=name;
        commit = UUID.randomUUID();
    }

    //Getters

    public UUID getCommit(){
        return commit;
    }

    public String getName() {
        return name;
    }

}
