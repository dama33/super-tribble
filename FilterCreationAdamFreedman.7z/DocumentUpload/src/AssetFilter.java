public class AssetFilter {
    private String fieldName;
    private double value;
    private ComparisonSign comparisonSign;

    public AssetFilter(String fieldName, double value, ComparisonSign comparisonSign) {
        this.fieldName = fieldName;
        this.value = value;
        this.comparisonSign = comparisonSign;
    }


    public double getValue() {
        return value;
    }

    public String getFieldName() {
        return fieldName;
    }

    public ComparisonSign getComparisonSign() {
        return comparisonSign;
    }
}
