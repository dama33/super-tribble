import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javafx.util.Pair;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.lang.reflect.Type;
import java.util.*;

public class Main {

    public static void main(String args[]) {

        MongoDatabase mongoDatabase;
        MongoClient mongoClient;
        AssetFilter adam;
        List<AssetFilter> assetFilters;
        MongoCollection<Document> mongoCollection;

        mongoClient = new MongoClient("localhost", 27017);
        mongoDatabase = mongoClient.getDatabase("local");
        mongoCollection = mongoDatabase.getCollection("mydb");

        assetFilters = new ArrayList<>();
        adam = new AssetFilter("Adam", 2,ComparisonSign.GREATERTHANOREQUALTO);

        assetFilters.add(adam);

        List<RunConfiguration> filteredRunConfigurations=getFilteredRunConfigurationList(mongoDatabase,mongoCollection,assetFilters);
        for(RunConfiguration runConfigurationInstance: filteredRunConfigurations){
            System.out.println(runConfigurationInstance.getCommit()+" "+runConfigurationInstance.getName());
        }
    }

    public static Bson filterCreator(ComparisonSign comparisonSign, String keyName, double keyValue)
    {
        return comparisonSign.apply(keyName, keyValue);
    }

    private static List<RunConfiguration> getFilteredRunConfigurationList(MongoDatabase mongoDatabase, MongoCollection<Document> mongoCollection, List<AssetFilter> assetFilters) {
        List<RunConfiguration> runConfigurationList=new ArrayList<>();
        Gson gson=new Gson();
        Type typeOfRunConfiguration=new TypeToken<RunConfiguration>(){}.getType();
        for (AssetFilter assetFilter : assetFilters) {

            ComparisonSign comparisonSign = assetFilter.getComparisonSign();
            String keyName = assetFilter.getFieldName();
            double keyValue = assetFilter.getValue();

            for (Document document : mongoCollection.find(filterCreator(comparisonSign, keyName, keyValue))) {
                runConfigurationList.add(gson.fromJson(document.toJson(), typeOfRunConfiguration));
            }
        }
        return runConfigurationList;
    }

    public static void addDocument(MongoDatabase mongoDatabase, MongoCollection mongoCollection){
        Scanner scanner = new Scanner(System.in);
        UUID settingUUID = UUID.randomUUID();

        List<Pair<String, String>> list = new ArrayList<Pair<String, String>>();
        int caseInput;

        //Im just messing around with this I will change this I just thought it was funny for now
        do {
            System.out.println("Enter a name to create a new entry or a number to stop");
            try {
                caseInput = scanner.nextInt();
            } catch (InputMismatchException t) {
                caseInput = 1;
            }

            if (caseInput == 1) {
                list.add(new Pair<String, String>(scanner.next(), String.valueOf((int) (Math.random() * 10))));
            } else {
                caseInput = 0;
            }
        } while (caseInput == 1);
        RunConfiguration runConfiguration = new RunConfiguration(list, "setting" + Math.random());
        if (runConfiguration.getListOfPairs().size() != 0) {
            Document document = new Document();


            for (int i = 0; i < runConfiguration.getListOfPairs().size(); i++) {
                document.put(runConfiguration.getListOfPairs().get(i).getKey(), Double.valueOf(runConfiguration.getListOfPairs().get(i).getValue()));
            }
            document.append("commit", runConfiguration.getCommit().toString())
                    .append("uuid", settingUUID.toString())
                    .append("name", runConfiguration.getName());
            mongoCollection.insertOne(document);
        }
    }
}
/* String query = new Gson().toJson(rc);
        System.out.println(query);
        Type typeOfT = new TypeToken<Document>(){}.getType();
        Document d = new Gson().fromJson(query,typeOfT);
        d.append("Name",RCName).append("UUID",settingUUID);
        coll.insertOne(d);
        */