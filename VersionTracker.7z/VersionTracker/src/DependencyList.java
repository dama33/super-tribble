import java.util.ArrayList;

public class DependencyList<T>{
    private ArrayList<DependencyNode<T>> dependencyList;

    public DependencyList() {
        dependencyList = new ArrayList<>();
    }

    public boolean add(DependencyNode node) {
        for (DependencyNode dn : dependencyList) {
            if (node.getName() == dn.getName()) {
                return false;
            }
        }
        dependencyList.add(node);
        return true;
    }

    public boolean addDependency(DependencyNode nodeA, DependencyNode nodeB, DependencyType dependencyType) {
        if (dependencyType.foundIn(nodeA, nodeB) || dependencyType.foundIn(nodeB,nodeA)) {
            return false;
        }
        else if(!(dependencyList.contains(nodeA) && dependencyList.contains(nodeB))){
            return false;
        }
        else{
            dependencyType.addConnection(nodeA,nodeB);
            return true;
        }
    }

}
