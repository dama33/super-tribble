import java.util.ArrayList;

public class DependencyNode<T> {
    private ArrayList<DependencyNode<T>> next;
    private String name;
    private T t;
    public DependencyNode(String name, T t){
        next=new ArrayList<>();
        this.name=name;
        this.t = t;
    }


    public T getT(){
        return t;
    }

    public boolean foundInNext(DependencyNode<T> foundNode){
        for(DependencyNode nodePointer:next){
            if(nodePointer.name==foundNode.name){
                return true;
            }
        }
        return false;
    }

    public ArrayList<DependencyNode<T>> getNext() {
        return next;
    }

    public void setOneNextValue(DependencyNode<T> next) {
        this.next.add(next);
    }

    public String getName() {
        return name;
    }
}
