public enum DependencyType {
    AToB{
        public boolean foundIn(DependencyNode nodeA,DependencyNode nodeB){
            if(nodeA.foundInNext(nodeB)){
                return true;
            }
            return false;
        }

        public void addConnection(DependencyNode nodeA,DependencyNode nodeB){
            nodeA.setOneNextValue(nodeB);
        }
    },
    BToA{
        public boolean foundIn(DependencyNode nodeA,DependencyNode nodeB){
            if(nodeB.foundInNext(nodeA)){
                return true;
            }
            return false;
        }

        public void addConnection(DependencyNode nodeA,DependencyNode nodeB){
            nodeB.setOneNextValue(nodeA);
        }
    };

    public abstract boolean foundIn(DependencyNode nodeA,DependencyNode nodeB);
    public abstract void addConnection(DependencyNode nodeA,DependencyNode nodeB);
}
