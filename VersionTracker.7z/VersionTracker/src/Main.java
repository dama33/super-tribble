
public class Main {
    public static void main(String[] args){
        DependencyList<String> list=new DependencyList<String>();
        DependencyNode<String> nodeA=new DependencyNode<String>("A","A");
        DependencyNode<String> nodeB=new DependencyNode<String>("B","B");

        list.add(nodeA);
        list.add(nodeB);

        System.out.println(list.addDependency(nodeA,nodeB,DependencyType.AToB));
        System.out.println(list.addDependency(nodeA,nodeB,DependencyType.AToB));
    }
}
